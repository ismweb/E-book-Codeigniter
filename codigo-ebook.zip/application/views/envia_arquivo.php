<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>Upload de arquivo - E-book codeigniter da Agência Ismweb</title>		
</head>
<body>
	<h1>Upload de arquivo</h1>
	<?php
		//Iniciamos no formulário
		echo form_open_multipart('upload/enviar');      
			//Campo imput type file			
			echo form_upload('arquivo');      
			echo '<br /><br />';
			//Botão submit
			echo form_submit('submit', 'Enviar arquivo');
		echo form_close();
		//Fechamos o fomulário
	?>		
</body>
</html>

