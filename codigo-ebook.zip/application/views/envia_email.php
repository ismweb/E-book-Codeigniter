<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>Enviar E-mail - E-book codeigniter da Agência Ismweb</title>		
</head>
<body>
	<h1>Enviar E-mail</h1>
	<?php
		//Iniciamos no formulário
		echo form_open('email/enviar');      
			//Campo imput type file			
			echo form_label('Nome', 'nome');
			echo '<br />';
			echo form_input('nome');   

			echo '<br />';
			echo form_label('Assunto', 'assunto');
			echo '<br />';
			echo form_input('assunto');     

			echo '<br />';
			echo form_label('Email', 'email');
			echo '<br />';
			echo form_input('email');      

			echo '<br />';
			echo form_label('Mensagem', 'mensagem');
			echo '<br />';
			echo form_textarea('mensagem');

			echo '<br /><br />';
			//Botão submit
			echo form_submit('submit', 'Enviar email');
		echo form_close();
		//Fechamos o fomulário
	?>		
</body>
</html>

