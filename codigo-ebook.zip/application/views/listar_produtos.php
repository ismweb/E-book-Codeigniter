<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>Listar Produto - E-book codeigniter da Agência Ismweb</title>	  	
</head>
<body>
	<h1>Listrar produtos</h1>
  <a href="produtos/add" title="Novo produto">Novo produto</a> 
  <br /> <br />
  <table border="1" width="400">
    <tr>
      <td>Nome produtos</td>
      <td>Preço</td>  
      <td>Ações</td>      
    </tr>
    <?php
      foreach($produtos as $produto){
        echo '<tr>';
          echo '<td>'.$produto->nome.'</td>';
          echo '<td>'.$produto->preco.'</td>';
          echo '<td>
                  <a href="'.base_url('index.php/produtos/edit/'.$produto->id) .'" title="Atualizar produtos">Editar</a> | 
                  <a href="'.base_url('index.php/produtos/del/'.$produto->id) .'" title="Apagar produtos">Apagar</a>
                </td>';
        echo '</tr>';
      }
    ?>
  </table>	
</body>
</html>

