<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>Mensagem  - E-book codeigniter da Agência Ismweb</title>		
</head>
<body>
	<h1>Formulário</h1>		
  <?php
    echo '<p>'.$this->session->flashdata('msg').'</p>';    
    echo form_open(current_url(), array('id'=>'form', 'name'=>'form'));            
      echo form_label('Valor', 'valor');
      echo '<br />';
      echo form_input(array('name'=>'valor', 'autocomplete'=>'off'), set_value('valor'), '');              
      echo '<br /><br />';
      echo form_submit('submit', 'Enviar');
    echo form_close();    
  ?>    
</body>
</html>

