<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>Validando Formulário  - E-book codeigniter da Agência Ismweb</title>		
</head>
<body>
	<h1>Validando Formulário</h1>

		
  <?php

    echo '<p>'.validation_errors().'</p>';

    //Iniciamos no formulário
    echo form_open(current_url(), array('id'=>'form', 'name'=>'form'));      
      //Campo imput type text    
      echo form_label('Nome', 'nome');
      echo '<br />';
      echo form_input(array('name'=>'nome', 'autocomplete'=>'off'), set_value('nome'), '');  

      //Campo imput type text e-mail
      echo '<br />';
      echo form_label('E-mail', 'email');
      echo '<br />';
      echo form_input(array('name'=>'email', 'autocomplete'=>'off'), set_value('email'), '');  
      
      //Campo imput type text numero
      echo '<br />';
      echo form_label('Número', 'numero');
      echo '<br />';
      echo form_input(array('name'=>'numero', 'autocomplete'=>'off'), set_value('numero'), '');  

      //Campos senhas
      echo '<br />';
      echo form_label('Senha', 'senha');
      echo '<br />';
      echo form_input(array('name'=>'senha', 'autocomplete'=>'off')); 

      echo '<br />';
      echo form_label('Repetir senha', 'senha1');
      echo '<br />';
      echo form_input(array('name'=>'senha1', 'autocomplete'=>'off')); 
      
      echo '<br /><br />';
      //Botão submit
      echo form_submit('submit', 'Enviar');
    echo form_close();
    //Fechamos o fomulário
  ?>    

</body>
</html>

