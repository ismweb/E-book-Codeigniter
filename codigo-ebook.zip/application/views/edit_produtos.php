<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>Edit Produto - E-book codeigniter da Agência Ismweb</title>		
</head>
<body>
	<h1>Edit produto</h1>

		<!-- Formulário de novo cadastro  -->
        <form action="<?php echo base_url('index.php/produtos/salvar') ?>" name="form_add" method="post">
          
          <!-- Input text nome do produtos -->          
          	<p>
          		<label>Nome</label>
          		<input type="text" name="nome" value="<?php echo $produto->nome ?>">
          	</p>
          <!-- fim input text nome produtos -->

          <!-- Input text preço do produtos -->
          <p>          
              <label>Preço</label>
              <input type="text" name="preco" value="<?php echo $produto->preco ?>">
          </p>
          <!-- fim input text preco produtos -->
          
          <!-- Button submit(enviar) formulário -->          
          <p>  
              <input type="hidden" name="id" value="<?php echo $produto->id ?>">          
              <button type="submit">Cadastrar</button>            
          </p>
          <!-- Button submit(enviar) formulário -->                    
        </form>
        <!--Fim formulário de novo cadastro  -->
</body>
</html>

