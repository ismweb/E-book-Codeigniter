<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>E-book codeigniter da Agência Ismweb</title>	
	<!-- Arquivos CSS -->
	<link href="<?php echo base_url(); ?>css/estilo.css" rel="stylesheet">
</head>
<body>
	<div class="header">		
		<img src="<?php echo base_url(); ?>img/ismcursos-logotipo.png" alt="Ismcursos">
		<h1>E-book codeigniter da Agência Ismweb</h1>			
	</div>
	<div class="content">
		<p>Faça um de nossos curso em nosso portal.</p>
		<p><a href="http://cursos.ismweb.com.br" title="Ismcuros"> http://cursos.ismweb.com.br</a></p>
		<p><a href="#" class="botao" title="Testar arquivo JS">Testar arquivo JS</a></p>
	</div>
	<div class="footer">
		<p>E-book de Codeigniter Agência Ismweb Cursos Online - Todos os direitos reservados</p>
		<p><img src="<?php echo base_url(); ?>img/ismcursos-logotipo.png" alt="Ismcursos"></p>	
	</div>
	<!-- Arquivos JS -->	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>js/main.js"></script>
</body>
</html>