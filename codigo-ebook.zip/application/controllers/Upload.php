<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller {

	//Contruct do Controller
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form'));
	}

	//Função principal
	public function index()
	{		
		//Carrega a view com formulário de upload
		$this->load->view('envia_arquivo');				
	}


	//Função enviar
	public function enviar()
	{
		
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size'] = 100;
		$config['max_width'] = 1024;
		$config['max_height'] = 768;

		$this->load->library('upload', $config);		

		if ( ! $this->upload->do_upload('arquivo')){			
			echo $this->upload->display_errors();
			echo '<a href="'.base_url('index.php/upload').'" title="Enviar outro arquivo">Enviar outro arquivo</a>';
		} else {
			echo '<pre>';
				print_r($this->upload->data());
			echo '</pre>';
			echo '<a href="'.base_url('index.php/upload').'" title="Enviar outro arquivo">Enviar outro arquivo</a>';
		}		
	}
	
}
/* Ebook de Condeigniter - Agência Ismweb - cursos.ismweb.com.br
 * Controller Upload.php
 * application/controllers/Upload.php 
 */

