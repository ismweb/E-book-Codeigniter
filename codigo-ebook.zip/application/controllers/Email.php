<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email extends CI_Controller {

	//Contruct do Controller
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form'));
	}

	//Função principal
	public function index()
	{		
		//Carrega a view com formulário de upload
		$this->load->view('envia_email');				
	}


	//Função enviar
	public function enviar()
	{
		//Carregamos a library email						
		$this->load->library('email');

		//Configurações de envio
		$config['protocol'] = 'smtp';
        $config['mailtype'] = 'html';

        //Dados do SMTP
        $config['smtp_host'] = 'smtp.seuservidor.com.br';
        $config['smtp_port'] = 'porta do servidor smtp';
        $config['smtp_user'] = 'email de acesso ao smtp';
        $config['smtp_pass'] = 'senha de acesso';

        //Inicializamos
		$this->email->initialize($config);

		//Montamos o corpo do email
		$mensagem = '<h3>Enviado pelo site</h3>';
		$mensagem .= '<br />Nome: '. $this->input->post('nome');
		$mensagem .= '<br />E-mail: '. $this->input->post('email');
		$mensagem .= '<br />Assunto: '. $this->input->post('assunto');
		$mensagem .= '<br />Mensagem: '. $this->input->post('mensagem');

		//Fazemos o envio
		$this->email->from('contato@ismweb.com.br', 'Envido pelo site');
		$this->email->to('claytonmergulhao@hotmail.com');						
		$this->email->subject($this->input->post('assunto'));
		$this->email->message($mensagem);
		
		if($this->email->send()){
			echo "Email enviado com sucesso!";
		} else {
			echo 'Ocorreu um erro tente novamente.';
			echo '<a href="'.base_url('index.php/email').'" title="Tentar novamente">Tentar novamente</a>';
		}
					
	}
	
}
/* Ebook de Condeigniter - Agência Ismweb - cursos.ismweb.com.br
 * Controller Email.php
 * application/controllers/Email.php 
 */

