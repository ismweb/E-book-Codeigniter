<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teste extends CI_Controller {

	public function index()
	{
		$this->load->view('teste');
	}

	public function ola()
	{
		echo 'Essa é uma função adicional <br />';
		echo 'No controller Teste.php';
	}

}
