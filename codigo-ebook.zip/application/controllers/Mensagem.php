<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mensagem extends CI_Controller {

	//Contruct do Controller
	public function __construct()
	{
		parent::__construct();		
		$this->load->library(array('session', 'form_validation'));
		$this->load->helper(array('form'));		
	}

	//Função principal
	public function index()
	{				
		$this->form_validation->set_rules('valor', 'Valor', 'required|numeric');
		if ($this->form_validation->run()==TRUE){
			$valor = $this->input->post('valor');
			if($valor > 10){
				$this->session->set_flashdata('msg','<h1>O valor é maior que 10!</h1>');		
			} else {
				$this->session->set_flashdata('msg','<h4>O valor é menor que 10!</h4>');		
			}
			redirect('mensagem');
		}	
		$this->load->view('criar_mensagem');				
	}		
	
}
/* Ebook de Condeigniter - Agência Ismweb - cursos.ismweb.com.br
 * Controller Mensagem.php
 * application/controllers/Mensagem.php 
 */

