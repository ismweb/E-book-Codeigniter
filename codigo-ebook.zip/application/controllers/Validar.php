<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Validar extends CI_Controller {

	//Contruct do Controller
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form'));
		$this->load->library(array('form_validation'));
	}

	//Função principal
	public function index()
	{		
		
		//Validação do campo Nome
		$this->form_validation->set_rules('nome', 'Nome', 'required|min_length[3]');

		//Validação do campo e-mail
		$this->form_validation->set_rules('email', 'E-mail', 'valid_email');
		
		//Validação do campo número
		$this->form_validation->set_rules('numero', 'NÚMERO', 'required|numeric|min_length[3]|max_length[5]', array('numeric' => 'o campo %s é permitido somente número.', 'max_length'=>'No campo %s é permitido no máximo 5 caracteres'));
		
		//Validação dos campos senha
		$this->form_validation->set_rules('senha', 'Senha', 'trim|required|matches[senha1]');
		$this->form_validation->set_rules('senha1', 'Repita senha', 'trim|required');

		//Setamos a mensagem de erro que a senha não confere
		$this->form_validation->set_message('matches', 'A senha não corresponde');

		//Fazemos a verificação se todas as validações foram feitas
		if ($this->form_validation->run()==TRUE){

			//Se as validações foram feitas o formulário enviado
			echo '<h3>Formulário enviado</h3>';
			echo '<pre>';
				print_r($this->input->post());
			echo '</pre>';

		} else {

			//Caso contrário voltamos ou carregamos nossa view com o form
			$this->load->view('validar_form');				

		}
		
	}	
	
}
/* Ebook de Condeigniter - Agência Ismweb - cursos.ismweb.com.br
 * Controller Validar.php
 * application/controllers/Validar.php 
 */

