<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produtos extends CI_Controller {

	//Função index vai listar todos os registro em nosso banco de dados.
	public function index()
	{
		//Carrega o Model Produto
		$this->load->model('produtos_model', 'produtos');					

		//Pegamos os dados da consultar e armazenamos na Array() $data;
		$data['produtos'] = $this->produtos->getProdutos();


		//Carregamos a view listarprodutos e passamos como parametro a array produtos que guarda todos os produtos da db produtos
		$this->load->view('listar_produtos', $data);				
	}

	//Função add vai adicionar um novo registro em nosso banco de dados.
	public function add()
	{
		$this->load->view('add_produtos');
	}

	//Função edit vai atualizar um registro em nosso banco de dados.
	public function edit($id=NULL)
	{
		//Verifica se foi passado um ID, se não vai para a página listar produtos
		if($id == NULL) {
			echo '<h3>Você deve passar um id.</h3>';
			echo '<a href="'.base_url('index.php/produtos/add').'" title="Novo produtos">Novo produtos</a> | ';
			echo '<a href="'.base_url('index.php/produtos').'" title="listar produtos">listar produtos</a>';
		} else {
			//Carrega o Model Produtos				
			$this->load->model('produtos_model', 'produtos');					

			//Criamos uma array onde vai guardar os dados do produto e passamos como parametro para view;	
			$data['produto'] = $this->produtos->getProdutoByID($id);

			//Carrega a View
			$this->load->view('edit_produtos', $data);

		}
	}

	//Função para salvar um novo regitro e para autualziar um registro.
	public function salvar()
	{
		//Carrega o Model Produtos				
		$this->load->model('produtos_model', 'produtos');

		//Pega dados do post e guarda na array $dados
		$dados['nome'] = $this->input->post('nome');
		$dados['preco'] = $this->input->post('preco');
							
		//Verifica se foi passado via post a id do produtos
		if ($this->input->post('id') != NULL) {		
			//Se foi passado ele vai fazer atualização no registro.	
			$this->produtos->editarProduto($dados, $this->input->post('id'));
		} else {
			//Se Não foi passado id ele adiciona um novo registro
			$this->produtos->addProduto($dados);
		}	
						
		echo '<h3>Produto cadastrado com sucesso!</h3>';
		echo '<a href="'.base_url('index.php/produtos/add').'" title="Novo produtos">Novo produtos</a> | ';
		echo '<a href="'.base_url('index.php/produtos').'" title="listar produtos">listar produtos</a>';													
	}


	//Função del vai excluir um registro em nosso banco de dados.
	public function del($id=NULL)
	{		
		//Verifica se foi passado um ID
		if($id == NULL) {
			echo '<h3>Você deve passar um id.</h3>';
			echo '<a href="'.base_url('index.php/produtos/add').'" title="Novo produtos">Novo produtos</a> | ';
			echo '<a href="'.base_url('index.php/produtos').'" title="listar produtos">listar produtos</a>';
		} else {
			//Carrega o Model Produtos				
			$this->load->model('produtos_model', 'produtos');

			//Faz a consulta no banco de dados pra verificar se existe
			$query = $this->produtos->getProdutoByID($id);

			//Verifica se foi encontrado um registro com a ID passada
			if($query != NULL) {				
				//Executa a função apagarProdutos do produtos_model
				$this->produtos->apagarProduto($query->id);	
				echo '<h3>Produto apagado com sucesso!</h3>';
				echo '<a href="'.base_url('index.php/produtos/add').'" title="Novo produtos">Novo produtos</a> | ';
				echo '<a href="'.base_url('index.php/produtos').'" title="listar produtos">listar produtos</a>';			
			} else {
				//Se não encontrou nenhum registro no banco de dados com a ID passada ele volta para página listar produtos
				echo '<h3>Você deve passar um id.</h3>';
				echo '<a href="'.base_url('index.php/produtos/add').'" title="Novo produtos">Novo produtos</a> | ';
				echo '<a href="'.base_url('index.php/produtos').'" title="listar produtos">listar produtos</a>';
			}
		}		
	}
}
/* Ebook de Condeigniter - Agência Ismweb - cursos.ismweb.com.br
 * Controller Prdoutos.php
 * application/controllers/produtos.php 
 */

