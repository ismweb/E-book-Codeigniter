<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sessao extends CI_Controller {

	//Contruct do Controller
	public function __construct()
	{
		parent::__construct();		
		$this->load->library(array('session'));
	}

	//Função principal
	public function index()
	{				
		$dadosSession = array( 
			'nomeUsuario' => 'Agência Ismweb Cursos on-line', 
			'emailUsuario' => 'contato@ismweb.com.br', 
			'logado' => TRUE 
		); 

		$this->session->set_userdata($dadosSession);						
	}	

	public function exibir()
	{	
		$nome = $this->session->userdata('nomeUsuario');
		$email = $this->session->userdata('emailUsuario');

		echo '<h3>'.$nome.'</h3>';
		echo '<h4>'.$email.'</h4>';

	}

	
}
/* Ebook de Condeigniter - Agência Ismweb - cursos.ismweb.com.br
 * Controller Session.php
 * application/controllers/Session.php 
 */

