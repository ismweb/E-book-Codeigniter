<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Produtos_model extends CI_Model
{	
    
    //Adiciona um novo produtos na tabela produtos
    public function addProduto($dados=NULL)
    {
    if ($dados != NULL):
        $this->db->insert('produtos', $dados);      
    endif;
    }

	//Lista todos os produtos da tabela produtos    
    public function getProdutos()
    {                                 
        $query = $this->db->get("produtos");
        return $query->result();
    }

    //Get produtos by id
    public function getProdutoByID($id=NULL)
    {
        if ($id != NULL){            
            $this->db->where('id', $id);                    
            $this->db->limit(1);            
            $query = $this->db->get("produtos");                
            return $query->row();   
        }
    }  

    //Atualizr um produto na tabela produtos
    public function editarProduto($dados=NULL, $id=NULL)
    {        
        if($dados != NULL && $id != NULL){     
            $this->db->update('produtos', $dados, array('id'=>$id));              
        }
    } 

    //Apaga um produtos na tabela produtos 
    public function apagarProduto($id=NULL){
        if ($id != NULL):
            $this->db->delete('produtos', array('id'=>$id));            
        endif;
    } 
             	 	
}
/* Ebook de Condeigniter - Agência Ismweb - cursos.ismweb.com.br
 * Model Produtos_model.php
 * application/controllers/Produtos_model.php 
 */
