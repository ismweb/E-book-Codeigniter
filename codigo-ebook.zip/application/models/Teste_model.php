<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Teste_model extends CI_Model
{	
    /*
     * Model Teste
     * Conteudo do e-book Codeigniter 3 conceitos básicos.     
     */  


             	 	
}
//application/models/Teste_model.php
