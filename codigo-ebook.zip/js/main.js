$(document).ready(function($) {

	$('.botao').click(function(){
		alert('Exemplo de arquivo JS.\nAgência ismweb - Curos online.');
	});

});